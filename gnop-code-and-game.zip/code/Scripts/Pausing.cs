﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pausing : MonoBehaviour
{

    public GameObject[] pauseObjs;
    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 1;
        pauseObjs = GameObject.FindGameObjectsWithTag("OnPause");
        hidePause();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void showPause()
    {
        Time.timeScale = 0;
        foreach (GameObject g in pauseObjs)
        {
            g.SetActive(true);
        }
    }

    public void hidePause()
    {
        Time.timeScale = 1;
        foreach (GameObject g in pauseObjs)
        {
            g.SetActive(false);
        }
    }
}
