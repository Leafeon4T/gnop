﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI : MonoBehaviour
{
    public Rigidbody2D AIRig;
    GameObject ball;
    Vector2 p;
    // Start is called before the first frame update
    void Start()
    {
        AIRig.velocity = new Vector2(0, -2);
        ball = GameObject.FindGameObjectWithTag("Ball");
    }

    // Update is called once per frame
    void Update()
    {
        p = transform.position;
        if(p.y < ball.transform.position.y)
        {
            AIRig.velocity = new Vector2(0, 1);
        }
        else if (p.y > ball.transform.position.y)
        {
            AIRig.velocity = new Vector2(0, -1);
        }
    }
}
