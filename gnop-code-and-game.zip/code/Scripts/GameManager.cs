﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static int points = 0;
    public GUISkin layout;
    GameObject ball;
    GameObject pauser;
    GameObject strt;

    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 0;
        ball = GameObject.FindGameObjectWithTag("Ball");
        pauser = GameObject.FindGameObjectWithTag("PauseMenu");
        strt = GameObject.FindGameObjectWithTag("OnStart");
        strt.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("escape"))
        {
            if (Time.timeScale == 1)
                pauser.SendMessage("showPause", 0.5f, SendMessageOptions.RequireReceiver);
            else
                pauser.SendMessage("hidePause", 0.5f, SendMessageOptions.RequireReceiver);
            //            Application.Quit();
        }
    }

    public static void Score(string wallID)
    {
        if (wallID == "Wall3")
        {
            points++;
        }
        else
        {
            points--;
        }
    }

    public void SetScore(int s)
    {
        points = s;
    }

    public void startGame()
    {
        strt.SetActive(false);
        Time.timeScale = 1;
    }

    public void endGame()
    {
        Application.Quit();
    }

    void OnGUI()
    {
        GUI.skin = layout;
        GUI.Label(new Rect(Screen.width / 2 - 100, 50, 200, 200), "Score: " + points);
//        if(GUI.Button(new Rect(Screen.width / 2 - 60, 35, 120, 53), "Restart"))
//        {
//            points = 0;
//            ball.SendMessage("Restart", 0.5f, SendMessageOptions.RequireReceiver);
//        }
        if(points == 10)
        {
            GUI.Label(new Rect(Screen.width / 2 - 150, 200, 2000, 1000), "You Win!");
            ball.SendMessage("Reset", null, SendMessageOptions.RequireReceiver);
        }
        else if(points == -10)
        {
            GUI.Label(new Rect(Screen.width / 2 - 150, 200, 2000, 1000), "You Lose");
            ball.SendMessage("Reset", null, SendMessageOptions.RequireReceiver);
        }
    }
}
