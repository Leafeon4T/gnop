﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bounce : MonoBehaviour
{

    public int speed = 2;
    public Rigidbody2D ballrig;

    // Start is called before the first frame update
    void Start()
    {
        Invoke("RdmDir", 2);
    }

    void RdmDir()
    {
        float rdm = Random.Range(0, 2);
        if(rdm < 1)
        {
            ballrig.velocity = new Vector2(speed * 2, speed * -1);
        }
        else
        {
            ballrig.velocity = new Vector2(speed * -2, speed * -1);
        }
    }

    void Reset()
    {
        ballrig.velocity = new Vector2(0, 0);
        transform.position = new Vector2(0, 0);
    }

    public void Restart()
    {
        Reset();
        Invoke("RdmDir", 1);
    }
//    // Update is called once per frame
//    void Update()
//    {
//        
//    }
}
