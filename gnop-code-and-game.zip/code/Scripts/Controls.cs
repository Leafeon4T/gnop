﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controls : MonoBehaviour
{
    //    // Start is called before the first frame update
    //    void Start()
    //    {
    //        
    //    }

    public int speed = 2;
    public Rigidbody2D rig;

    // Update is called once per frame
    void Update()
    {
        //   float xvel = Input.GetAxis("Horizontal");
        float xvel = 0;
        float yvel = Input.GetAxis("Vertical");

        rig.velocity = new Vector2(xvel, yvel*speed);
    }
}
